# BanglaShield AI — Complete Context & Engineering Handoff

**Last updated:** 22 November 2026 (Bangladesh time)  
**Project:** BanglaShield AI — AI Safety and Cybersecurity for Bangladesh  
**Current objective:** Add one integrated AI Cyber Agent to the original working BanglaShield AI V3 product.  
**Audience:** A new coding agent in a fresh terminal or development environment.

> Read this entire document before writing code. The latest decisions in this handoff supersede earlier Guardian prompts. The existing product is the foundation; the failed standalone Guardian preview is NOT the foundation. Do not interpret previous ambitious architecture proposals as a requirement to build a separate platform.

## 1. Executive summary

BanglaShield AI is a Bangla-first scam prevention and digital safety product for ordinary Bangladeshis, including people with little technical knowledge. The original V3 already provides a working application architecture with scam checking, voice and image submission, message/link analysis, educational simulations, evidence visualization, community reporting and safety guidance.

The next task is to extend that product with one intelligent, conversational cybersecurity agent. Users should speak or write naturally, attach an image or recording, get evidence-based security analysis, and see simple visual explanations of what happened, what might happen next, and how to protect themselves.

**Do not build a separate website, replace the existing home page, redesign the product, or introduce a new complex navigation structure.** Add a single new section integrated into the existing website and reuse existing backend services. The developer may make narrowly scoped changes to the existing header/router/translations to integrate the new section; unrelated features should remain unchanged.

## 2. Canonical links and historical context

| Resource | URL / status |
|---|---|
| Canonical original GitHub repository | https://github.com/Shamimhasan8/BanglaShield-AI |
| Original deployed website (user supplied) | https://bangla-shield-ai.vercel.app/ |
| Earlier V3 preview (user supplied) | https://preview-chat-6d134e14-fe73-42bc-8876-40c7382f2fc7.space-z.ai/ |
| Earlier V3 feedback document (user supplied) | https://docs.google.com/document/d/1ggkSZkQtzRPbAqzo3Bi3p919RdOSLWFYCQ31TOd6mco/edit?usp=sharing |
| Failed standalone Guardian preview — do not use as baseline | https://preview-chat-382be165-8c93-45a4-b580-0ae95ef8a7e0.space-z.ai/ |
| Initial shared conversation | https://chatgpt.com/s/t_6afd9ce1467481919f4e79ba2c18428f |
| Initial shared conversation | https://chatgpt.com/share/6b005c8a-5aec-83ee-bda2-e3ddde807d58 |

Historical Figma design work established the calm, human-centered design direction. No independently verified Figma file/node ID is available in this handoff; the original repository's implemented UI is the immediately usable reference. Do not claim pixel parity to an inaccessible Figma file. The historical preview and document links are references, not proof that they still work.

## 3. Why this project exists

The project originated around the AI safety/cybersecurity challenge in Bangladesh, with a strong focus on practical harm prevention and competition demonstration. Bangladesh-specific examples include:

- A family loses its monthly income to a fraudulent mobile banking request.
- An AI-generated voice impersonates a migrant worker and pressures a parent into sending money.
- A student is tricked by a fake scholarship form that requests a PIN or NID.
- A worker pays an overseas employment or fake visa agency.
- A scammer instructs the victim to install remote-access software or a malicious APK.
- A manipulated image or screenshot is used to create trust or spread deception.

The product is not simply a generic AI chatbot. Its value is actionable, understandable security evidence before the user makes an irreversible decision. The startup vision is proactive phone and digital safety; the initial deliverable is a real working web agent integrated into the original product, followed by verified native capabilities.

Product principle: **Show the threat. Explain the evidence. Protect the person.**

Bangla principle: **ক্ষতি হওয়ার আগেই সুরক্ষা।**

## 4. Repository baseline — independently inspected

The original repository was cloned with its full Git history and inspected locally. On 22 November 2026 the checkout was clean and contained 150 tracked files and 8 commits. The inspected V3 HEAD was:

```text
3b4e891238a523001c6d176227c7df3aeb32b0e7
release: BanglaShield AI 3.0 — production-ready scam protection platform
```

This is the inspected reference, not a guarantee that the remote main branch has not changed. Check the latest remote on starting work and preserve user changes.

### Existing stack

- Next.js 16 App Router, React 19, TypeScript.
- Tailwind CSS, shadcn/Radix UI, Lucide icons, Framer Motion, Zustand.
- Prisma 6 and local SQLite database.
- `z-ai-web-dev-sdk` for server-side language model, ASR and VLM calls.
- Zod validation, client-side jsQR decoding, evidence-driven visualizations.
- Existing citizen experience is a hash-routed SPA inside the root Next.js page, sharing its original header/footer.
- Existing design uses warm ivory, forest green, sage, restrained clay-red warnings, clear Bangla typography, and accessible controls.

### Existing features (from repository source and README)

| Feature | Existing behavior to preserve |
|---|---|
| Scam checker | Message, voice, screenshot, link, QR analyses |
| Voice Safety Lab | Microphone capture, audio upload, editable ASR transcript; no confirmed acoustic voice authenticity |
| Image checker | Screenshot OCR and visual observations, review before scam analysis; NOT a validated AI-generated image classifier |
| Shield Lens 3.0 | Evidence-linked attack replay; play/pause, scrubbing, speed, safe/risky branches, graph |
| Agent Activity Explorer | Real pipeline events with timing, model attempts and safety outcomes |
| Community Threat Watch | Redacted user reports, analyst moderation, approved community alerts |
| ScamAcademy | 12 bilingual lessons, interactive questions and progress |
| Help Center | Emergency guidance and verified resource directory; verify current contact info before adding new resources |
| Judge Demo Mode | Six labeled synthetic scenarios |
| Privacy settings | Anonymous visitor sessions and data deletion controls |

### Important source files

| Path (relative to repository root) | Responsibility |
|---|---|
| `src/app/page.tsx` | Original SPA entry |
| `src/components/shield/app.tsx` | `ShieldApp`, dynamic pages, hash router, original header/footer |
| `src/components/shield/header.tsx` | Original navigation desktop/mobile |
| `src/components/shield/router.tsx` | Hash navigation |
| `src/components/shield/i18n.tsx` | Bangla/English translation layer |
| `src/components/shield/store.ts` | Settings and visitor state |
| `src/components/shield/pages/check.tsx` | Existing microphone recorder, audio upload, ASR review, screenshot and QR input |
| `src/components/shield/pages/analysis.tsx` | Results and evidence |
| `src/components/shield/pages/shield-lens.tsx` | Interactive threat replay |
| `src/components/shield/pages/demo.tsx` | Original demo workflows |
| `src/components/shield/demo-presets.ts` | Synthetic scenarios |
| `src/components/shield/api.ts` | Client API helpers |
| `src/lib/types.ts` | Existing `AnalysisResultV3`, bilingual contracts, modes and events |
| `src/lib/agent.ts` | Server-side structured analyst model call; 25s attempt timeout |
| `src/lib/multimodal.ts` | `transcribeAudio`, `extractImageContent`; ASR/VLM extraction, 45s extraction timeout, redaction |
| `src/lib/pipeline.ts` | Deterministic processing orchestration, background jobs, event trace |
| `src/lib/heuristics.ts` | BN/Banglish/EN deterministic scam indicator extraction |
| `src/lib/redact.ts` | Sensitive information redaction |
| `src/lib/safety-gate.ts` | Schema and evidence validation, policy and recommendation checks |
| `src/lib/fallback.ts` | Honest deterministic result if provider fails |
| `src/lib/graph.ts` | Evidence-linked graph construction |
| `src/lib/auth.ts`, `src/lib/rate-limit.ts`, `src/lib/db.ts` | Authorization, abuse controls, data access |
| `src/app/api/v1/analyses/` | Existing analysis session, input, status, result, replay, cancellation/deletion routes |
| `prisma/schema.prisma`, `prisma/seed.ts` | Existing data layer and demo setup |
| `docs/RELEASE-AUDIT.md`, `README.md` | Claims, setup, known limitations and baseline tests |

### Available demo assets (verified in repository)

```text
public/demo/rahela-call.wav
public/demo/scholarship-scam.png
public/demo/demo-qr.png
```

## 5. Prior verification findings and limitations

The repository's own release audit reports 19 of 20 checks passed, including Bengali speech recognition with an explicit provider limitation and editable-transcript fallback. This audit was written by the prior implementation; its assertions are not a new independent end-to-end test report. Production compilation was not verified by that audit. There was no tracked automated test suite identified in the prior source inspection.

Known technical issues to account for when integrating the new module:

- Existing ASR may garble Bangla speech. Reuse the review path, then evaluate a better multilingual/Bangla ASR provider. Never present garbled output as reliable.
- Existing image extraction is OCR/VLM observation, not AI-generated image forensics. Implement a dedicated, independently evaluated image detector/provenance path instead of renaming existing results.
- Existing voice analysis detects social engineering content, not confirmed acoustic AI voice cloning.
- The earlier audit's ownership tests cover cancel/delete. Prior code inspection found case input/read/status/result/replay paths that may rely on a case ID rather than verifying ownership. Reverify and fix the narrow shared authorization path before exposing cases through the agent; every new endpoint must enforce ownership.
- Existing background execution uses an in-process set/queue. It may not survive serverless restarts or multiple workers. Use durable jobs for production or document the limitation and implement recoverable terminal states for the demo.
- SQLite is suitable for a local single-instance demonstration. For multi-instance deployment use a supported durable database and job store.
- Existing `OFFLINE_DEMO` means synthetic deterministic backend analysis, not guaranteed network-independent browser usage. If adding offline replay, verify it actually works without network and label it separately.
- `#/recovery` may route to Community because an earlier router branch catches it. This is a narrow preexisting issue; do not refactor unrelated routes. Log it and fix only if authorized or necessary for the new agent's recovery workflow.
- The existing `db:push` script uses `--accept-data-loss`; `db:seed` and reset are potentially destructive. Do not run them against existing or production data.

## 6. Failed Guardian preview — what we learned

The previous prompt expanded the project into a standalone Guardian site with seven separate sections, which missed the user's main request. The user rejected it due to broken/slow functionality and poor experience relative to the original product.

The failed preview was opened and manually examined. Observed findings:

- The header shown was standalone BanglaShield Guardian with Protection Center, Sensors, Threat Fusion, Demonstrations, Cyber Assistant, Incidents and Privacy — not the original BanglaShield product shell.
- Initial page displayed an establishing-session spinner before the dashboard became available.
- The Rahela simulated incoming call advanced to the unknown-caller caution stage, correctly labeled simulation and rule-based fallback.
- After clicking `Answer & analyze voice`, the button remained disabled/loading during the observed test interval. Completion of the voice workflow was not verified; no root cause was established by browser inspection alone.
- Cyber Assistant presented a separate consent-gated entry screen. The assistant's conversational response was not independently tested.
- The visible Sensors interface provided number input, audio upload, and gated message/APK features. Dedicated AI-generated image detection was not visible in the tested interface.
- The page states Android companion is a scaffold and that it does not pair with or control the user's phone. Actual native protection was not independently verified.

Do not claim every feature in the failed preview is broken; the test was targeted, not exhaustive. Do not migrate that separate dashboard as-is. The user specifically wants the original wrapper and existing product with a new integrated Cyber Agent.

## 7. Final agreed scope (supersedes all previous Guardian prompts)

**Feature name:** AI Cyber Agent / BanglaShield Guardian (feature name only, not replacement product branding).

**Primary route:** `#/guardian` inside the original `ShieldApp` hash router. Add one compact link to existing desktop and mobile navigation and translated label. Keep all previous routes, home, header/footer and feature behavior. Avoid an independent `/guardian` application shell, new landing page or second dashboard.

### P0 — deliver these working first

1. **Cybersecurity assistant:** a single bilingual conversational workspace, guest accessible, with real server-side model reasoning and evidence-grounded recommendations.
2. **Voice security:** recording/playback/upload, real transcription, editable transcript, scam-content analysis, actual waveform, suspicious phrase highlights, warning and recommendations.
3. **AI-generated image and manipulation detection:** real uploaded image (not fixture only), validated image/provenance analysis, honest uncertainty and explainable evidence, separate screenshot scam analysis from authenticity analysis.
4. **Working demo:** a polished, animated Rahela call scenario that finishes reliably. Actual supported user-input analysis must also work with new inputs. Clearly label simulation, rule fallback, and fixture replay.
5. **Existing product compatibility:** all original functions remain available, design remains visually consistent, no broken navigation.

### P1 — only after P0 acceptance

- Suspicious message/link analysis through existing safe pipeline.
- User-selected APK static analysis, no execution/installation; verify support before claiming.
- Multi-signal threat correlation inside the same authorized session.
- Native Android companion: verified incoming-call metadata screening, permissions, user-selected share and local safety checks.

### P2 — partnership / supported integration, not a web guarantee

- Authorized cellular conversation audio processing and timely live interventions.
- Managed-device or OEM/telecom app-install policy integrations.
- Authorized financial-provider anti-fraud integration.

No blanket promise of AGI, ASI, whole-phone protection, 100% accuracy, or training on billions of samples. Build bounded expert cybersecurity intelligence with pretrained models, tools, policy and measured evidence. Novelty is a product hypothesis, not a verified worldwide-first claim.

## 8. UX and visualization specification

Single page inside the existing shell: heading, a short Bangla-first welcome, four quick actions (Voice Security, Check Image, Check Message/Link, Ask Agent), conversation history and composer with text, microphone and attachment controls. Add a compact security result card in conversation after each tool analysis. Use progressive disclosure for advanced evidence and timelines.

Suggested Bangla hero: **আপনার ব্যক্তিগত সাইবার নিরাপত্তা সহকারী**  
Suggested copy: **আপনার সমস্যা বলুন। বাংলাশিল্ড আপনাকে সাহায্য করবে।**

Reuse existing design tokens: approximately ivory `#F4F1EB`, forest `#2F5746`, sage `#DDE8DF`, clay-red `#A44435`, ink `#202C26`, secondary text `#59665F`. Verify actual existing CSS and fonts rather than replacing them. Use original icons, spacing, responsive behavior, Bangla/English settings. Preserve aesthetic: warm, human, premium, not neon cybersecurity or generic AI gradients.

Required useful visualization:

- Microphone/audio: recording timer, waveform generated from actual audio, playback, transcript, timestamped phrases where ASR supports timestamps.
- Analysis: status from real processing events, risk category, evidence references, observed vs inferred vs hypothetical findings, user next steps.
- Image: image preview, provenance/metadata results, detected anomalies only when evidence supports them, uncertainty and safe recommendations. No fabricated heatmaps.
- Demo: simulated mobile incoming call, answer, play audio, explain why the message is suspicious, show warning and user decision, then show safe verification instructions. Show what happened and potential consequence separately.
- Optional correlated threat visual: call → payment pressure → suspicious link → app installation request → possible loss. Link only evidence-backed events; label hypothetical branches.

Use motion meaningfully, with reduced-motion support and responsive layouts (320px up), keyboard, screen reader labels, contrast and large touch targets. Target WCAG 2.2 AA. No fake progress timers or fake risk percentage. Initial UI must not block on optional session or model calls; provide timeouts/errors/retry/cancel. Consent should be clear and contextual, not a maze of screens; never silently collect data.

## 9. Technical system design

```mermaid
flowchart TD
    A[Original BanglaShield UI] --> B[Integrated Cyber Agent]
    B --> C[Consent and validation]
    C --> D[Redact and route modality]
    D --> E[Existing scam analysis pipeline]
    D --> F[Speech and image specialist adapters]
    E --> G[Evidence and reasoning]
    F --> G
    G --> H[Independent safety gate]
    H --> I[Conversation and visual result]
    H --> J[Authorized user action]
```

Architecture: do not create a separate unrestricted agent. Reuse existing pipeline, data contracts, deterministic detection, redaction and recommendation whitelist. Implement typed provider adapters for new tools and bounded orchestrator routing. A user-authorized event is input data, never instructions. The model does not execute arbitrary device commands, fetch arbitrary links or perform financial actions.

### Core harness layers

1. Input validation and consent (modality, size limits, real MIME, session ownership).
2. Privacy/redaction (minimize raw data; no secret credentials, OTPs/PINs, private keys; raw audio/image not persisted by default; be transparent about actual provider processing/retention).
3. Tool selection (whitelisted text, scam pipeline, ASR, image detector/provenance, safe link parser, optional static APK inspection).
4. Specialist analysis (pretrained models, calibrated evaluations, bounded latency, structured outputs).
5. Evidence and optional session-scoped correlation (timestamps, source provenance, relevant relations, deduplicate, expiry, counterevidence).
6. Independent deterministic safety/authorization gate (validate schema and evidence refs, uncertainty, allowlisted actions, no model-granted permissions, no fabricated contacts).
7. Presentation/evaluation (bilingual concise explanations, meaningful visualization, actual model/policy version and events, safe error recovery).

Reuse the four existing scam risk states: `HIGH_RISK`, `CAUTION`, `INSUFFICIENT_EVIDENCE`, `NO_RISK_INDICATORS` (not a guarantee of safety). Image authenticity is a separate claim: `likely synthetic`, `possible manipulation`, `no strong synthetic indicators`, or `insufficient evidence`. Keep modality/source independent of execution mode. Preserve `LIVE_AI`, `RULE_BASED_FALLBACK`, `OFFLINE_DEMO`; if adding a new mode such as `OFFLINE_REPLAY`, clearly describe meaning and verify it. Simulated device events must never look like real sensor events.

### Proposed additive implementation paths

```text
src/components/shield/pages/guardian.tsx       # original shell/router integration
src/components/shield/guardian/              # composer, recording, image result, evidence, demo
src/lib/guardian/                            # contracts, orchestration, adapters, policy integration
src/app/api/v1/guardian/                     # versioned authenticated server endpoints
tests/guardian/                              # unit, integration and end-to-end tests
docs/guardian/                              # setup, safety, evaluation, verification
android/guardian-companion/                  # later independently verified native module
```

This is a proposed map, not implemented code. Prefer established repository conventions. Reuse existing analysis IDs/results where possible. New sessions/events and optional model-run records must have authenticated ownership checks (including result reads, stream, replay, upload, delete); use scoped guest credentials, idempotency, abuse limits, bounded workers, cancellation and deletion. Do not expose secrets in the client. No destructive schema changes or seed operations. Keep new data scoped and migrations compatible.

## 10. Voice and mobile capability boundaries

The user's long-term vision is that an intelligent security agent identifies an unknown caller, recognizes scam tactics during the call, warns the person and can stop harmful activity. Implementation must be accurate and platform-compliant:

| Capability | What can actually be implemented |
|---|---|
| Website microphone | `getUserMedia` + `MediaRecorder`, explicit user consent, recording/stop/playback, authorized audio upload and ASR. This is not ordinary cellular-call capture. Stop tracks on exit and consent revocation. |
| Authorized app-controlled voice calls | With appropriate participant notice/consent, a controlled VoIP/audio session can analyze streaming segments and give warnings; user can end that session. Optional after core demo. |
| Native Android incoming screening | User-selected `ROLE_CALL_SCREENING`, official `CallScreeningService`, available caller metadata, local reputation checks, respond within 5 seconds. Unknown number is not proof; allow on uncertainty/timeout; respect emergency and platform restrictions. |
| Cellular conversation capture | Ordinary third-party apps and websites cannot freely record arbitrary call audio. Native privileged/platform/authorized integration is required. No covert recording, root tricks, speakerphone bypass or accessibility abuse. |
| Ending a cellular call | Do not claim arbitrary live call termination. Legitimate pre-answer screening may allow/silence/reject in supported, opted-in circumstances; warn the person and let them decide to end an ongoing ordinary call. |
| APK inspection | User-selected file, isolated static metadata/signing/permission/hash inspection, never execute/install; unknown != malware. |
| Whole-device app blocking | Not ordinary website functionality. Only appropriate OS/managed-device/OEM permissions can enforce installation restrictions. |
| Financial transactions | Never request credentials or transfer funds. Authorized bank/financial-provider integration is a separate future effort. |

Official references (reverify platform, OS version and distribution rules during implementation):

- Android Call Screening: https://developer.android.com/reference/android/telecom/CallScreeningService
- Audio capture: https://developer.android.com/media/platform/sharing-audio-input
- Telecom: https://developer.android.com/develop/connectivity/telecom
- Package visibility: https://developer.android.com/training/package-visibility
- Device policy: https://developer.android.com/reference/android/app/admin/DevicePolicyManager
- Android share-sheet: https://developer.android.com/develop/ui/compose/sharing/receive
- On-device AI: https://developer.android.com/ai/gemini-nano/
- OWASP GenAI security: https://genai.owasp.org/

## 11. Model strategy and evaluation

Use pretrained models, not a fabricated custom superintelligence. Existing ZAI server-only SDK is a usable adapter where configured. Evaluate alternative licensed multilingual ASR (e.g. https://github.com/openai/whisper) for Bangla/Banglish if necessary. Use real model outputs and validate them. For image authenticity, independently evaluate an appropriate synthetic-image detector, verify signatures/provenance if present, distinguish absent provenance from invalid provenance, and treat metadata/visual observations as weak clues. Image detector score is not universally reliable; avoid guaranteed verdicts. The existing VLM only extracts visible text and visual notes; general vision model opinion is not a forensic detector. If a qualified detector cannot be installed or called, return an honest insufficient-evidence outcome and report the missing capability, rather than inventing detection.

Use properly licensed, consented data and separate speakers/images/generation families/scam campaigns across evaluation splits. Include benign, adversarial, mixed-language, ambiguous, compressed/cropped and out-of-distribution cases. Measure precision, recall, false-positive/negative rate, abstention and coverage, ASR transcription error, image robustness, latency, safety violations. Compare multi-signal fusion to single-event analysis at matched coverage if implemented. Report only actual measured results, with limitations.

## 12. Hackathon demonstration script

**Primary story: Rahela — a mother's trust, a son's voice.** A mother receives an unfamiliar simulated call. The caller claims to be her son working abroad and says: “মা, আমি বিপদে পড়েছি। এখনই ৫০,০০০ টাকা পাঠাও। কাউকে বলো না।”

1. Start demo inside the existing Cyber Agent.
2. Animated phone shows unknown caller (not automatically fraud).
3. Play original `rahela-call.wav` synthetic recording.
4. Show actual ASR result or clearly identified fixture transcript/manual review if provider fails.
5. Detect urgent payment and secrecy, possible family impersonation, show evidence and uncertainty.
6. Warn: **এখনই টাকা পাঠাবেন না। পরিচিত নম্বরে ফোন করে সত্যতা যাচাই করুন।**
7. Let user confirm a simulated protective choice; show hypothetical safe/risky consequences distinctly.
8. Show final incident explanation. Do not claim actual money was saved or an actual phone call was stopped.

Then upload a non-demo image and show authenticity analysis; ask a fresh Bangla question and demonstrate an actual assistant response. This proves that the product is not merely a slideshow. If a provider fails, show a clear error and supported fallback, and have a separately labeled network-independent demo replay available if feasible.

Additional stories: Karim's fake visa/job agency; Nusrat's fake scholarship request asking for NID/PIN; legitimate unknown caller; ambiguous audio; benign image; suspicious APK metadata (safe fixture); suspicious link. Avoid overused bKash-only pitch; the family voice story demonstrates AI safety relevance and emotional stakes.

## 13. Start in a new environment (commands)

Run these in a new working directory, or inspect an existing clean checkout first. Do not overwrite existing work.

```bash
git clone https://github.com/Shamimhasan8/BanglaShield-AI.git
cd BanglaShield-AI
git status --short
git log -1 --oneline
git switch -c feature/integrated-cyber-agent
```

Inspect `README.md`, `docs/RELEASE-AUDIT.md`, `package.json`, `.env.example`, current framework configuration, applicable AGENTS instructions, and installed runtime. The repository includes `bun.lock` and `package-lock.json`; select the existing supported workflow and avoid unnecessary lockfile churn. Examples (use whichever runtime is actually installed):

```bash
# Bun workflow if supported by the environment:
bun install --frozen-lockfile
bun run db:generate
bun run dev

# npm workflow if supported by the lockfile/environment:
npm ci
npm run db:generate
npm run dev
```

Initialize a disposable local database using a reviewed non-destructive setup/migration path. `.env.example` uses `DATABASE_URL="file:../db/custom.db"`; use an isolated database and a unique random `SESSION_SECRET`, never ship sample secrets. The ZAI SDK provider is runtime-configured in the original repo; do not assume credentials exist outside its original environment, and never expose them. Implement adapter + clearly labeled fallback if unconfigured. Do not run `db:push --accept-data-loss`, reset, or seed on existing data. Inspect and use a fresh disposable demo database if seeding is needed.

Existing build command: `npm run build` or `bun run build` (includes Next standalone copying). Existing start script uses Bun; verify runtime and standalone configuration. Run the baseline before changes and capture screenshots and tests. Verify production build with the appropriate runtime, not just dev server.

## 14. Mandatory execution and acceptance plan

| Phase | Acceptance criterion |
|---|---|
| 0. Original baseline | Clone, record SHA and status; run original site, capture baseline screenshots and behavior; do not change existing product unnecessarily. |
| 1. Integrate one section | `#/guardian` loads inside original header/footer; new navigation link works desktop/mobile; all original routes work. |
| 2. Real assistant | Fresh Bangla/English questions receive actual backend responses and meaningful evidence; structured error and timeout states. |
| 3. Voice | Real record/stop/play/upload; ASR or honest editable fallback; warning, actual waveform, evidence; permissions handled. |
| 4. Image | Actual new image can be selected, previewed, analyzed; provenance/detector findings and uncertainty; test different images; no fake detector. |
| 5. Demo | Rahela demo reaches final state in one uninterrupted run, including model failure fallback; no indefinite spinner. Clearly labeled simulation. |
| 6. Safety | Auth ownership for every relevant endpoint, uploads/size/MIME checks, prompt injection, abuse limits, redaction, cancellation, retry, consent revocation, deletion. |
| 7. Visual QA | Original aesthetic, accessible responsive layouts at 320/390/768/desktop widths, no clipping, focus and reduced motion, readable Bangla. |
| 8. Final release | Lint, typecheck, unit/integration, browser E2E, production build, original workflows regression, real screenshots and executed results. |
| 9. Optional later | APK static analysis, multi-signal fusion, native Android screen/permission tests only after P0 passes. |

Test both provider available and unavailable. Include benign unknown number, non-scam OTP safety advisory, confusing Banglish transcript, malformed AI output, prompt injection in images/transcript, unauthorized case read/input/status/result/replay, duplicate submission, refresh, invalid uploads, network timeout, no microphone permission, no provider token and true offline replay if offered. A passing screenshot alone is not proof of a functioning backend. Measure actual elapsed times and report terminal status. Test original home, check, analysis, Shield Lens, learning, help, community, privacy, and existing demo; avoid unrelated rewrites.

## 15. Copy-ready kick-off prompt for the new coding agent

> Act as a principal full-stack engineer and cybersecurity AI harness engineer. Read this entire context file, then clone the original repository https://github.com/Shamimhasan8/BanglaShield-AI and verify its baseline. **Do not build a new website.** Preserve the entire existing BanglaShield AI V3 UI and working features. Add only one integrated AI Cyber Agent at `#/guardian` using the existing header, footer, styles, language settings and components. Minimal header/router/translation edits are authorized for that integration; no unrelated redesign or refactor.
>
> Implement P0 sequentially: (1) unified bilingual conversational UI and real server-side cybersecurity assistant; (2) consented microphone recording, playback, audio upload, real ASR with editable transcript, evidence-based voice scam analysis and waveform; (3) actual uploaded image authenticity/manipulation analysis using qualified detection and provenance evidence where available, with honest uncertainty; (4) a complete animated Rahela demo and clear real-input versus simulated/fallback labels. Reuse existing `agent.ts`, `multimodal.ts`, `pipeline.ts`, `heuristics.ts`, `safety-gate.ts`, `AnalysisResultV3` and Shield Lens wherever appropriate. Add only necessary specialist adapters. Do not substitute hardcoded sample results for live inputs. If model credentials or platform permissions are unavailable, implement supported fallback and state exact limitations.
>
> Build reliable APIs, input validation, ownership, privacy, independent safety gates, cancellation/timeouts, error handling, and regression tests. Explain observed evidence, inference, unknowns and user next action in simple Bangla. The model must not secretly monitor a phone, handle credentials, execute arbitrary actions, or claim unauthorized cellular-call/app-install control. Native Android and static APK inspection are follow-on work after core P0 passes. Follow the official platform documents in this handoff.
>
> Run the product and tests yourself. Verify real chatbot replies, live voice recording and fresh image upload with different inputs, the entire Rahela demo, mobile/desktop UI, old features, error/fallback handling, typecheck/lint and production build. Fix failures before declaring success. Report exact changed files, actual test results, screenshots, launch steps, and a capability matrix listing tested, unverified, simulated and unavailable features. Do not push or deploy without authorization. Begin now; work phase by phase and deliver a functioning extension, not just a mockup or another dashboard.

## 16. What is NOT done yet

- The new integrated Cyber Agent has not been implemented in the original checkout in the conversation that produced this handoff.
- The prior standalone Guardian preview is rejected; it is not the final deliverable.
- No newly validated image authenticity model or native Android live cellular audio capability is established.
- No new verified production build or full suite of end-to-end results for the integrated agent exists.
- External deployments, model credentials and native permissions depend on the new environment and user authorization.

**Final success definition:** Opening the original BanglaShield AI app still shows the existing product. Clicking one new AI Cyber Agent entry opens a polished, simple, Bangla-first workspace that genuinely analyzes user text, voice and images, explains what happened and what to do, and provides a reliable animated presentation. Everything claimed as working must be backed by execution evidence.
