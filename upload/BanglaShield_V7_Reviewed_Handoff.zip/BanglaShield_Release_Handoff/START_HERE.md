# Start here

This package is a review and implementation handoff, not a deployed redesign.

1. Read REVIEW_AND_TASKS.md for independently observed failures, successful tests, design critique and judge questions.
2. Give IMPLEMENTATION_PROMPT.md to the coding agent as its complete task.
3. Attach BanglaShield_V7_Complete_Design.zip for visual references and BanglaShield_AI_Complete_Context.md for historical context.
4. Give the agent the repository URL and access to application/deployment logs. Configure the OpenRouter key only in its protected environment, never in chat or the browser bundle.
5. Supply the new competition name/link when available. Its panel, scoring and submission requirements have not been verified. OpenRouter spending limits remain configurable.

Suggested message to the next agent:

> Read every file in this handoff. Execute IMPLEMENTATION_PROMPT.md against the current BanglaShield-AI repository. Preserve current functionality and data, implement the supplied V7 design, repair the documented release blockers, integrate Guardian and OpenRouter, and publish only measured model metrics. Verify actual frontend/backend behavior and production build. Do not push or deploy without authorization. Report tested, failed, unavailable, simulated and unverified capabilities honestly.

Original design and historical context attachments are preserved, not rewritten. Their descriptions of local integrations may differ from current remote main; use the reviewed baseline and then inspect current HEAD. The V7 navigation patch did not apply to the reviewed main.
